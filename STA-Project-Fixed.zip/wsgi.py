from vercel_app import app

# This is for Vercel deployment
if __name__ == "__main__":
    app.run()
